import React from "react";
const SpecsSection = () => {
  return (
    <div className="relative">
      {/* Specs section content goes here */}
    </div>
  );
};
export default SpecsSection;